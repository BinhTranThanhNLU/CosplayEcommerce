package com.springboot.cosplay.service;

import com.springboot.cosplay.entity.*;
import com.springboot.cosplay.exception.BusinessException;
import com.springboot.cosplay.exception.ResourceNotFoundException;
import com.springboot.cosplay.repository.CartItemRepository;
import com.springboot.cosplay.repository.CartRepository;
import com.springboot.cosplay.repository.OrderRepository;
import com.springboot.cosplay.repository.ProductVariantRepository;
import com.springboot.cosplay.responseDto.CartItemResponse;
import com.springboot.cosplay.responseDto.CartResponse;
import com.springboot.cosplay.responseDto.CheckoutResponse;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class CartService {

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final ProductVariantRepository productVariantRepository;
    private final OrderRepository orderRepository;

    public CartService(CartRepository cartRepository,
                       CartItemRepository cartItemRepository,
                       ProductVariantRepository productVariantRepository,
                       OrderRepository orderRepository) {
        this.cartRepository = cartRepository;
        this.cartItemRepository = cartItemRepository;
        this.productVariantRepository = productVariantRepository;
        this.orderRepository = orderRepository;
    }

    @Transactional
    public CartResponse getCart(User user) {
        Cart cart = getOrCreateCart(user);
        return toResponse(cart);
    }

    @Transactional
    public int getCartCount(User user) {
        Cart cart = getOrCreateCart(user);

        if (cart.getItems() == null) {
            return 0;
        }

        return cart.getItems()
                .stream()
                .mapToInt(item -> item.getQuantity() == null ? 0 : item.getQuantity())
                .sum();
    }

    @Transactional
    public CartResponse addToCart(User user, Integer productVariantId, Integer quantity) {
        if (productVariantId == null) {
            throw new BusinessException("Vui lòng chọn phân loại sản phẩm");
        }

        int safeQuantity = quantity == null || quantity < 1 ? 1 : quantity;

        Cart cart = getOrCreateCart(user);

        ProductVariant variant = productVariantRepository.findById(productVariantId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy biến thể sản phẩm"));

        int stock = variant.getStock() == null ? 0 : variant.getStock();

        if (stock <= 0) {
            throw new BusinessException("Sản phẩm đã hết hàng");
        }

        CartItem item = cartItemRepository.findByCartAndProductVariant(cart, variant)
                .orElseGet(() -> CartItem.builder()
                        .cart(cart)
                        .productVariant(variant)
                        .quantity(0)
                        .build());

        int currentQuantity = item.getQuantity() == null ? 0 : item.getQuantity();
        int nextQuantity = currentQuantity + safeQuantity;

        if (nextQuantity > stock) {
            throw new BusinessException("Số lượng trong giỏ hàng vượt quá tồn kho");
        }

        boolean isNewItem = item.getId() == null;

        item.setQuantity(nextQuantity);

        CartItem savedItem = cartItemRepository.save(item);

        if (cart.getItems() == null) {
            cart.setItems(new ArrayList<>());
        }

        if (isNewItem) {
            cart.getItems().add(savedItem);
        }

        return toResponse(cart);
    }

    @Transactional
    public CartResponse updateQuantity(User user, Integer itemId, Integer quantity) {
        Cart cart = getOrCreateCart(user);

        CartItem item = cartItemRepository.findById(itemId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy sản phẩm trong giỏ hàng"));

        if (!item.getCart().getId().equals(cart.getId())) {
            throw new BusinessException("Bạn không có quyền chỉnh sửa sản phẩm này");
        }

        int safeQuantity = quantity == null ? 1 : quantity;

        if (safeQuantity <= 0) {
            if (cart.getItems() != null) {
                cart.getItems().remove(item);
            }

            cartItemRepository.delete(item);

            return toResponse(cart);
        }

        int stock = item.getProductVariant().getStock() == null
                ? 0
                : item.getProductVariant().getStock();

        if (safeQuantity > stock) {
            throw new BusinessException("Số lượng trong giỏ hàng vượt quá tồn kho");
        }

        item.setQuantity(safeQuantity);
        cartItemRepository.save(item);

        return toResponse(cart);
    }

    @Transactional
    public CartResponse removeItem(User user, Integer itemId) {
        Cart cart = getOrCreateCart(user);

        CartItem item = cartItemRepository.findById(itemId)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy sản phẩm trong giỏ hàng"));

        if (!item.getCart().getId().equals(cart.getId())) {
            throw new BusinessException("Bạn không có quyền xóa sản phẩm này");
        }

        if (cart.getItems() != null) {
            cart.getItems().remove(item);
        }

        cartItemRepository.delete(item);

        return toResponse(cart);
    }

    @Transactional
    public CheckoutResponse checkout(User user, String shippingAddress) {
        Cart cart = getOrCreateCart(user);

        if (cart.getItems() == null || cart.getItems().isEmpty()) {
            throw new BusinessException("Giỏ hàng đang trống");
        }

        if (shippingAddress == null || shippingAddress.trim().isEmpty()) {
            throw new BusinessException("Vui lòng nhập địa chỉ giao hàng");
        }

        Long total = cart.getItems()
                .stream()
                .mapToLong(item -> getItemPrice(item) * safeQuantity(item))
                .sum();

        Shop shop = cart.getItems()
                .get(0)
                .getProductVariant()
                .getProduct()
                .getShop();

        Order order = Order.builder()
                .user(user)
                .shop(shop)
                .totalAmount(total)
                .status(OrderStatus.PENDING)
                .shippingAddress(shippingAddress.trim())
                .createdAt(LocalDateTime.now())
                .build();

        List<OrderItem> orderItems = cart.getItems()
                .stream()
                .map(item -> OrderItem.builder()
                        .order(order)
                        .productVariant(item.getProductVariant())
                        .quantity(safeQuantity(item))
                        .price(getItemPrice(item))
                        .rental(false)
                        .build())
                .toList();

        if (order.getItems() == null) {
            order.setItems(new ArrayList<>());
        }

        order.getItems().addAll(orderItems);

        Order savedOrder = orderRepository.save(order);

        cartItemRepository.deleteByCart(cart);

        cart.getItems().clear();

        return CheckoutResponse.builder()
                .orderId(savedOrder.getId())
                .totalAmount(savedOrder.getTotalAmount())
                .status(savedOrder.getStatus().name())
                .build();
    }

    private Cart getOrCreateCart(User user) {
        return cartRepository.findByUser(user)
                .orElseGet(() -> {
                    Cart cart = Cart.builder()
                            .user(user)
                            .items(new ArrayList<>())
                            .build();

                    return cartRepository.save(cart);
                });
    }

    private CartResponse toResponse(Cart cart) {
        List<CartItemResponse> items = cart.getItems() == null
                ? List.of()
                : cart.getItems()
                  .stream()
                  .map(this::toItemResponse)
                  .toList();

        int totalQuantity = items.stream()
                .mapToInt(CartItemResponse::getQuantity)
                .sum();

        long totalAmount = items.stream()
                .mapToLong(CartItemResponse::getLineTotal)
                .sum();

        return CartResponse.builder()
                .id(cart.getId())
                .items(items)
                .totalQuantity(totalQuantity)
                .totalAmount(totalAmount)
                .build();
    }

    private CartItemResponse toItemResponse(CartItem item) {
        ProductVariant variant = item.getProductVariant();
        Product product = variant.getProduct();

        int quantity = safeQuantity(item);
        long price = getItemPrice(item);

        return CartItemResponse.builder()
                .id(item.getId())
                .productVariantId(variant.getId())
                .productId(product.getId())
                .productName(product.getName())
                .imageUrl(product.getImageUrl())
                .size(variant.getSize())
                .color(variant.getColor())
                .stock(variant.getStock())
                .quantity(quantity)
                .price(price)
                .lineTotal(price * quantity)
                .build();
    }

    private int safeQuantity(CartItem item) {
        return item.getQuantity() == null ? 0 : item.getQuantity();
    }

    private long getItemPrice(CartItem item) {
        Long price = item.getProductVariant().getSalePrice();
        return price == null ? 0L : price;
    }
}